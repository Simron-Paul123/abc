# Upgrade Plan: fintrack-api (20260821141525)

- **Generated**: 2026-08-21
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

> Version control is unavailable in this workspace; changes will remain uncommitted in the working directory.

## Available Tools

**JDKs**
- JDK 23.0.1: C:\Program Files\Java\jdk-23\bin (available, not required for target verification)
- JDK 25.0.2: C:\Users\User\AppData\Local\jdks\jdk-25.0.2\bin (installed for upgrade verification)
- JDK 21: not available (baseline will be skipped)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (no Maven installation detected; Maven will be installed for verification)
- Maven Wrapper: not present

## Guidelines

- Preserve the existing Spring Boot layered architecture and API behavior.
- Keep monetary values as BigDecimal and preserve existing validation and authorization controls.
- Update documentation that explicitly identifies the runtime version.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260821141525
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested runtime upgrade |
| Spring Boot | 3.5.5 | 3.5.5 | Already compatible with Java 25; retain to minimize scope |
| Maven | Not installed | 3.9+ | Required to build and test the Maven project |
| Spring Boot Maven plugin | 3.5.5 (parent-managed) | 3.5.5 | Already compatible with Java 25 |
| JUnit 5 / Spring Boot test | 3.5.5 (parent-managed) | 3.5.5 | Existing test infrastructure; verify on Java 25 |

## Derived Upgrades

- Install JDK 25 because the requested runtime target is Java 25.
- Install Maven 3.9.x because no Maven executable or wrapper is available.
- Retain Spring Boot 3.5.5 and its managed dependencies because no framework upgrade is required for Java 25.
- Update explicit documentation and workspace guidance from Java 21 to Java 25 to prevent stale runtime instructions.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| pom.xml | `java.version` | 21 | upgrade | 25 | Sets the compiler and Spring Boot build target to Java 25 |
| pom.xml | Spring Boot parent | 3.5.5 | retain | 3.5.5 | Compatible with Java 25; no unnecessary dependency churn |

### Source Code Changes

No Java source changes are required. The compatibility scan found no internal JDK imports, reflective access to JDK internals, removed Java APIs, or framework APIs affected by this runtime-only upgrade.

### Configuration Changes

No application runtime properties require changes. `application.properties` contains no Java-version-specific settings.

### CI/CD Changes

No CI/CD files were detected.

### Documentation and Workspace Guidance Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|-----------------|--------|
| README.md | Java prerequisite | Java 21 | Change to Java 25 | Keep setup instructions aligned with the supported runtime |
| .github/copilot-instructions.md | Technology section | Java 21 | Change to Java 25 | Keep project coding guidance aligned with the runtime |
| PR_DESCRIPTION.md | Java reference | Java 21 | Change to Java 25 | Remove stale upgrade documentation |
| PROMPTS.md | Java references | Java 21 | Change to Java 25 | Remove stale project prompt guidance |

### Risks & Warnings

- **JDK 25 availability**: Java 25 was not initially installed. **Mitigation**: Install and verify JDK 25 before applying the build target.
- **Build tool availability**: Maven is not installed and no wrapper exists. **Mitigation**: Install Maven 3.9.x and run compile/test verification with JDK 25.
- **Baseline unavailable**: JDK 21 is not installed, so the pre-upgrade baseline cannot be executed. **Mitigation**: Record the skipped baseline and require clean Java 25 compilation plus a 100% passing test suite.
- **Runtime-only compatibility**: Existing tests may not cover every JDK-dependent path. **Mitigation**: Run the complete test suite on Java 25 and inspect all failures before completion.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install and verify the target JDK and required Maven tool before changing project files.
  - **Changes to Make**: Use the installed JDK 25 and install Maven 3.9.x if needed.
  - **Verification**: List JDKs and Maven installations; expected JDK 25 and Maven 3.9.x are available.

- Step 2: Setup Baseline
  - **Rationale**: Establish pre-upgrade compilation and test evidence when the base JDK is available.
  - **Changes to Make**: None; JDK 21 is unavailable, so this step is skipped.
  - **Verification**: Record baseline as skipped because JDK 21 is not available.

- Step 3: Upgrade Java Target and Documentation
  - **Rationale**: Apply the requested runtime target and align all explicit project guidance.
  - **Changes to Make**: Apply the Dependency Changes and Documentation and Workspace Guidance Changes above.
  - **Verification**: Run `mvn clean test-compile -q` with JDK 25; expected successful main and test compilation.

- Step 4: CVE Validation and Fix
  - **Rationale**: Verify that the resolved dependency set has no known vulnerabilities after the upgrade.
  - **Changes to Make**: Scan direct dependencies; upgrade only vulnerable managed or direct versions if reported.
  - **Verification**: Compile after any fixes and rescan; expected no unresolved actionable CVEs.

- Step 5: Final Validation
  - **Rationale**: Confirm all goals, compile paths, and tests on the target runtime.
  - **Changes to Make**: Resolve any Java 25 build or test failures and remove temporary workarounds.
  - **Verification**: Run `mvn clean test -q` with JDK 25; expected 100% test pass rate, then run `mvn clean verify -Djacoco.skip=false` for coverage evidence.
