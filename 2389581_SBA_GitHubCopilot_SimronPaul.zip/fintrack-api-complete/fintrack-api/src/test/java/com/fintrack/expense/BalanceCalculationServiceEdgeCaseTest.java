package com.fintrack.expense;

import com.fintrack.expense.model.ParticipantShare;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.model.SharedExpenseRequest;
import com.fintrack.expense.model.SplitType;
import com.fintrack.expense.service.BalanceCalculationService;
import com.fintrack.expense.service.ExpenseValidationException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BalanceCalculationServiceEdgeCaseTest {

    private final BalanceCalculationService service = new BalanceCalculationService();
    private final UUID creator = UUID.randomUUID();
    private final UUID participant = UUID.randomUUID();

    @Test
    void equalSplitDistributesRemainderWithoutChangingTotal() {
        SharedExpenseRequest request = new SharedExpenseRequest(
                creator,
                "Coffee",
                new BigDecimal("10.00"),
                SplitType.EQUAL,
                List.of(new ParticipantShare(creator, null), new ParticipantShare(participant, null),
                        new ParticipantShare(UUID.randomUUID(), null)));

        SharedExpense expense = service.createExpense(request, creator);

        assertEquals(List.of(new BigDecimal("3.34"), new BigDecimal("3.33"), new BigDecimal("3.33")),
                expense.participants().stream().map(ParticipantShare::amount).toList());
        assertEquals(new BigDecimal("10.00"), expense.participants().stream()
                .map(ParticipantShare::amount)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    @Test
    void duplicateParticipantsAreRejected() {
        SharedExpenseRequest request = new SharedExpenseRequest(
                creator,
                "Dinner",
                new BigDecimal("20.00"),
                SplitType.EQUAL,
                List.of(new ParticipantShare(creator, null), new ParticipantShare(creator, null)));

        assertThrows(ExpenseValidationException.class, () -> service.createExpense(request, creator));
    }

    @Test
    void unauthorizedUserCannotCalculateBalancesForAnExpense() {
        UUID unauthorizedUser = UUID.randomUUID();
        SharedExpense expense = new SharedExpense(
                UUID.randomUUID(),
                creator,
                "Dinner",
                new BigDecimal("20.00"),
                SplitType.CUSTOM,
                List.of(new ParticipantShare(creator, new BigDecimal("10.00")),
                        new ParticipantShare(participant, new BigDecimal("10.00"))),
                Instant.now());

        assertThrows(ExpenseValidationException.class,
                () -> service.calculateNetBalances(unauthorizedUser, List.of(expense)));
    }

    @Test
    void opposingExpensesRemoveZeroNetBalance() {
        SharedExpense first = new SharedExpense(
                UUID.randomUUID(), creator, "Dinner", new BigDecimal("20.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(creator, new BigDecimal("10.00")),
                        new ParticipantShare(participant, new BigDecimal("10.00"))), Instant.now());
        SharedExpense second = new SharedExpense(
                UUID.randomUUID(), participant, "Taxi", new BigDecimal("20.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(participant, new BigDecimal("10.00")),
                        new ParticipantShare(creator, new BigDecimal("10.00"))), Instant.now());

        assertEquals(0, service.calculateNetBalances(participant, List.of(first, second)).size());
    }
}