package com.fintrack.expense;

import com.fintrack.expense.model.*;
import com.fintrack.expense.service.*;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class BalanceCalculationServiceTest {

    private final BalanceCalculationService service = new BalanceCalculationService();
    private final UUID creator = UUID.randomUUID();
    private final UUID user2 = UUID.randomUUID();
    private final UUID user3 = UUID.randomUUID();

    @Test
    void equalSplitAmongThreeParticipants() {
        var request = new SharedExpenseRequest(
                creator, "Dinner", new BigDecimal("120.00"), SplitType.EQUAL,
                List.of(new ParticipantShare(creator, null),
                        new ParticipantShare(user2, null),
                        new ParticipantShare(user3, null)));

        var result = service.createExpense(request, creator);

        assertEquals(new BigDecimal("40.00"), result.participants().get(0).amount());
        assertEquals(new BigDecimal("40.00"), result.participants().get(1).amount());
        assertEquals(new BigDecimal("40.00"), result.participants().get(2).amount());
    }

    @Test
    void customSplitMatchingTotalSucceeds() {
        var request = new SharedExpenseRequest(
                creator, "Trip", new BigDecimal("100.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(creator, new BigDecimal("20.00")),
                        new ParticipantShare(user2, new BigDecimal("30.00")),
                        new ParticipantShare(user3, new BigDecimal("50.00"))));

        assertDoesNotThrow(() -> service.createExpense(request, creator));
    }

    @Test
    void customSplitNotMatchingTotalFails() {
        var request = new SharedExpenseRequest(
                creator, "Trip", new BigDecimal("100.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(creator, new BigDecimal("20.00")),
                        new ParticipantShare(user2, new BigDecimal("20.00")),
                        new ParticipantShare(user3, new BigDecimal("50.00"))));

        assertThrows(ExpenseValidationException.class,
                () -> service.createExpense(request, creator));
    }

    @Test
    void oneParticipantFails() {
        var request = new SharedExpenseRequest(
                creator, "Solo", new BigDecimal("50.00"), SplitType.EQUAL,
                List.of(new ParticipantShare(creator, null)));

        assertThrows(ExpenseValidationException.class,
                () -> service.createExpense(request, creator));
    }

    @Test
    void unauthorizedCreatorFails() {
        UUID attacker = UUID.randomUUID();
        var request = new SharedExpenseRequest(
                creator, "Dinner", new BigDecimal("50.00"), SplitType.EQUAL,
                List.of(new ParticipantShare(creator, null),
                        new ParticipantShare(user2, null)));

        assertThrows(ExpenseValidationException.class,
                () -> service.createExpense(request, attacker));
    }

    @Test
    void netBalanceCalculationHandlesMultipleExpenses() {
        var e1 = new SharedExpense(UUID.randomUUID(), creator, "Dinner",
                new BigDecimal("120.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(creator, new BigDecimal("60.00")),
                        new ParticipantShare(user2, new BigDecimal("60.00"))), java.time.Instant.now());

        var e2 = new SharedExpense(UUID.randomUUID(), user2, "Taxi",
                new BigDecimal("40.00"), SplitType.CUSTOM,
                List.of(new ParticipantShare(user2, new BigDecimal("20.00")),
                        new ParticipantShare(creator, new BigDecimal("20.00"))), java.time.Instant.now());

        var balances = service.calculateNetBalances(user2, List.of(e1, e2));

        assertEquals(new BigDecimal("40.00"), balances.get(creator));
    }
}
