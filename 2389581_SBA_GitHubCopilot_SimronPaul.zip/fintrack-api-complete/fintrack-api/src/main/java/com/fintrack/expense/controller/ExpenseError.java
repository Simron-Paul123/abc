package com.fintrack.expense.controller;

public record ExpenseError(String code, String message) {
}