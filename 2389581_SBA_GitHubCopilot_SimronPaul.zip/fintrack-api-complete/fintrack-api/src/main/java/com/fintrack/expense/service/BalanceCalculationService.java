package com.fintrack.expense.service;

import com.fintrack.expense.model.ParticipantShare;
import com.fintrack.expense.model.SharedExpense;
import com.fintrack.expense.model.SharedExpenseRequest;
import com.fintrack.expense.model.SplitType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class BalanceCalculationService {
    private static final Logger log = LoggerFactory.getLogger(BalanceCalculationService.class);
    private static final int MONEY_SCALE = 2;
    private static final BigDecimal ZERO = BigDecimal.ZERO.setScale(MONEY_SCALE);

    private final List<SharedExpense> expenses = new CopyOnWriteArrayList<>();

    /** Creates and stores a validated shared expense for the authenticated creator. */
    @Transactional
    public SharedExpense createExpense(SharedExpenseRequest request, UUID authenticatedUserId) {
        validateRequest(request, authenticatedUserId);

        List<ParticipantShare> shares = request.splitType() == SplitType.EQUAL
                ? calculateEqualShares(request.totalAmount(), request.participants())
                : validateCustomShares(request.totalAmount(), request.participants());

        SharedExpense expense = new SharedExpense(
                UUID.randomUUID(),
                authenticatedUserId,
                request.description().trim(),
                request.totalAmount().setScale(MONEY_SCALE),
                request.splitType(),
                shares,
                Instant.now());
        expenses.add(expense);
        log.info("Shared expense created by user {} with {} participants",
                authenticatedUserId, shares.size());
        return expense;
    }

    /** Returns expenses visible to the authenticated user. */
    @Transactional(readOnly = true)
    public List<SharedExpense> getExpensesForUser(UUID authenticatedUserId) {
        requireAuthenticated(authenticatedUserId);
        return expenses.stream()
                .filter(expense -> isVisibleTo(expense, authenticatedUserId))
                .toList();
    }

    /** Calculates the requesting user's net balances across visible expenses. */
    @Transactional(readOnly = true)
    public Map<UUID, BigDecimal> calculateNetBalances(UUID requestingUserId,
                                                       List<SharedExpense> visibleExpenses) {
        requireAuthenticated(requestingUserId);
        if (visibleExpenses == null) {
            throw new ExpenseValidationException("Expenses are required");
        }

        Map<UUID, BigDecimal> balances = new HashMap<>();
        for (SharedExpense expense : visibleExpenses) {
            if (expense == null || !isVisibleTo(expense, requestingUserId)) {
                throw new ExpenseValidationException("User is not authorised for an expense");
            }

            UUID payer = expense.creatorId();
            for (ParticipantShare share : expense.participants()) {
                if (share.userId().equals(payer)) {
                    continue;
                }

                BigDecimal delta = share.userId().equals(requestingUserId)
                        ? share.amount()
                        : share.amount().negate();
                balances.merge(
                        share.userId().equals(requestingUserId) ? payer : share.userId(),
                        delta,
                    (existing, addition) -> existing.add(addition));
            }
        }

        balances.entrySet().removeIf(entry -> entry.getValue().compareTo(BigDecimal.ZERO) == 0);
        return balances;
    }

    private void validateRequest(SharedExpenseRequest request, UUID authenticatedUserId) {
        requireAuthenticated(authenticatedUserId);
        if (request == null) {
            throw new ExpenseValidationException("Expense request is required");
        }
        if (!authenticatedUserId.equals(request.creatorId())) {
            throw new ExpenseValidationException("Only the authenticated creator may create an expense");
        }
        if (request.totalAmount() == null || request.totalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new ExpenseValidationException("Expense total must be greater than zero");
        }
        if (request.totalAmount().scale() > MONEY_SCALE) {
            throw new ExpenseValidationException("Expense total has unsupported precision");
        }
        if (request.description() == null || request.description().isBlank()) {
            throw new ExpenseValidationException("Expense description is required");
        }
        if (request.participants() == null || request.participants().size() < 2) {
            throw new ExpenseValidationException("An expense requires at least two participants");
        }

        Set<UUID> participantIds = new HashSet<>();
        for (ParticipantShare participant : request.participants()) {
            if (participant == null || participant.userId() == null
                    || !participantIds.add(participant.userId())) {
                throw new ExpenseValidationException("Participant IDs must be unique and non-null");
            }
        }
    }

    private List<ParticipantShare> calculateEqualShares(BigDecimal total,
                                                         List<ParticipantShare> participants) {
        BigDecimal base = total.setScale(MONEY_SCALE, RoundingMode.DOWN)
                .divide(BigDecimal.valueOf(participants.size()), MONEY_SCALE, RoundingMode.DOWN);
        BigDecimal remainder = total.setScale(MONEY_SCALE).subtract(
                base.multiply(BigDecimal.valueOf(participants.size())));
        int remainderUnits = remainder.movePointRight(MONEY_SCALE).intValueExact();

        List<ParticipantShare> shares = new ArrayList<>();
        for (int index = 0; index < participants.size(); index++) {
            BigDecimal amount = base;
            if (index < remainderUnits) {
                amount = amount.add(BigDecimal.ONE.movePointLeft(MONEY_SCALE));
            }
            shares.add(new ParticipantShare(participants.get(index).userId(), amount));
        }
        return shares;
    }

    private List<ParticipantShare> validateCustomShares(BigDecimal total,
                                                         List<ParticipantShare> participants) {
        BigDecimal shareTotal = ZERO;
        for (ParticipantShare participant : participants) {
            if (participant.amount() == null || participant.amount().compareTo(BigDecimal.ZERO) <= 0
                    || participant.amount().scale() > MONEY_SCALE) {
                throw new ExpenseValidationException("Custom shares must be positive monetary values");
            }
            shareTotal = shareTotal.add(participant.amount());
        }
        if (shareTotal.compareTo(total) != 0) {
            throw new ExpenseValidationException("Custom shares must equal the expense total exactly");
        }
        return participants.stream()
                .map(participant -> new ParticipantShare(
                        participant.userId(), participant.amount().setScale(MONEY_SCALE)))
                .toList();
    }

    private boolean isVisibleTo(SharedExpense expense, UUID userId) {
        return expense.creatorId().equals(userId)
                || expense.participants().stream().anyMatch(participant -> participant.userId().equals(userId));
    }

    private void requireAuthenticated(UUID userId) {
        if (userId == null) {
            throw new ExpenseValidationException("Authenticated user is required");
        }
    }
}