package com.fintrack.transaction.service;

import com.fintrack.transaction.model.CreateTransactionRequest;
import com.fintrack.transaction.model.Transaction;
import com.fintrack.transaction.model.TransactionResponse;
import com.fintrack.transaction.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class TransactionService {
    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);

    private final TransactionRepository repository;
    private final CurrentUserProvider currentUserProvider;

    public TransactionService(TransactionRepository repository, CurrentUserProvider currentUserProvider) {
        this.repository = repository;
        this.currentUserProvider = currentUserProvider;
    }

    /** Creates a transaction owned by the authenticated user. */
    @Transactional
    public TransactionResponse create(CreateTransactionRequest request) {
        UUID authenticatedUserId = currentUserProvider.requireCurrentUserId();
        Transaction transaction = new Transaction(
                authenticatedUserId,
                request.amount(),
                request.description().trim(),
                request.currency());
        Transaction saved = repository.save(transaction);
        log.info("Transaction created for user {}", authenticatedUserId);
        return toResponse(saved);
    }

    /** Returns only transactions owned by the authenticated user. */
    @Transactional(readOnly = true)
    public List<TransactionResponse> getByUser(UUID requestedUserId) {
        UUID authenticatedUserId = currentUserProvider.requireCurrentUserId();
        requireOwner(requestedUserId, authenticatedUserId);
        return repository.findAllByUserIdOrderByCreatedAtDescIdDesc(authenticatedUserId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    /** Deletes all transactions belonging to the authenticated user. */
    @Transactional
    public long deleteAll(UUID requestedUserId) {
        UUID authenticatedUserId = currentUserProvider.requireCurrentUserId();
        requireOwner(requestedUserId, authenticatedUserId);
        long deleted = repository.deleteAllByUserId(authenticatedUserId);
        log.info("Deleted {} transactions for user {}", deleted, authenticatedUserId);
        return deleted;
    }

    private void requireOwner(UUID requestedUserId, UUID authenticatedUserId) {
        if (requestedUserId == null || !authenticatedUserId.equals(requestedUserId)) {
            throw new UnauthorizedAccessException("User is not authorised for this resource");
        }
    }

    private TransactionResponse toResponse(Transaction transaction) {
        return new TransactionResponse(
                transaction.getId(),
                transaction.getAmount(),
                transaction.getDescription(),
                transaction.getCurrency(),
                transaction.getCreatedAt());
    }
}
