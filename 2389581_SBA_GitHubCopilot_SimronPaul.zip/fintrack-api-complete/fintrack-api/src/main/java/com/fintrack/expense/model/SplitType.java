package com.fintrack.expense.model;

public enum SplitType {
    EQUAL,
    CUSTOM
}