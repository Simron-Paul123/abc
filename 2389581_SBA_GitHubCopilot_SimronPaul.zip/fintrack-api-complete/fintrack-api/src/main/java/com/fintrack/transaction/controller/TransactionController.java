package com.fintrack.transaction.controller;

import com.fintrack.transaction.model.CreateTransactionRequest;
import com.fintrack.transaction.model.TransactionResponse;
import com.fintrack.transaction.service.TransactionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionService service;

    public TransactionController(TransactionService service) {
        this.service = service;
    }

    /** Creates a transaction for the authenticated user. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TransactionResponse create(@Valid @RequestBody CreateTransactionRequest request) {
        return service.create(request);
    }

    /** Returns transactions belonging to the authenticated user. */
    @GetMapping("/user/{userId}")
    public List<TransactionResponse> getByUser(@PathVariable UUID userId) {
        return service.getByUser(userId);
    }

    /** Deletes all transactions belonging to the authenticated user. */
    @DeleteMapping("/user/{userId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAll(@PathVariable UUID userId) {
        service.deleteAll(userId);
    }
}
