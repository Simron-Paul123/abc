package com.fintrack.transaction.controller;

public record ApiError(String code, String message) {
}