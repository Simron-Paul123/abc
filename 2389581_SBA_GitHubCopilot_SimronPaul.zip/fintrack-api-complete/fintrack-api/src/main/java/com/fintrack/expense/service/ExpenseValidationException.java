package com.fintrack.expense.service;

public class ExpenseValidationException extends RuntimeException {
    public ExpenseValidationException(String message) {
        super(message);
    }
}