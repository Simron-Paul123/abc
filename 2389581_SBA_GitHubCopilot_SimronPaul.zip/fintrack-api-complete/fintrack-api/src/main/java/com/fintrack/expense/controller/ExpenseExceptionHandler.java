package com.fintrack.expense.controller;

import com.fintrack.expense.service.ExpenseValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExpenseExceptionHandler {

    @ExceptionHandler(ExpenseValidationException.class)
    public ResponseEntity<ExpenseError> handleValidation(ExpenseValidationException exception) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ExpenseError("EXPENSE_VALIDATION_ERROR", exception.getMessage()));
    }
}