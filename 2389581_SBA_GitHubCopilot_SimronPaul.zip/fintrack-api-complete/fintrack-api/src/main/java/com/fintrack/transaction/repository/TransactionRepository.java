package com.fintrack.transaction.repository;

import com.fintrack.transaction.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface TransactionRepository extends JpaRepository<Transaction, UUID> {
    List<Transaction> findAllByUserIdOrderByCreatedAtDescIdDesc(UUID userId);
    long deleteAllByUserId(UUID userId);
}
