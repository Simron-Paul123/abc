package com.fintrack.transaction.model;

//import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;



public record TransactionResponse(
        UUID id,
        BigDecimal amount,
        String description,
        String currency,
        Instant createdAt
) {}
