package com.fintrack.expense.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.UUID;

public record ParticipantShare(
        @NotNull UUID userId,
        @DecimalMin(value = "0.01") @Digits(integer = 17, fraction = 2) BigDecimal amount
) {
}