package com.fintrack.expense.controller;

import com.fintrack.expense.model.SharedExpenseRequest;
import com.fintrack.expense.model.SharedExpenseResponse;
import com.fintrack.expense.service.BalanceCalculationService;
import com.fintrack.transaction.service.CurrentUserProvider;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {
    private final BalanceCalculationService service;
    private final CurrentUserProvider currentUserProvider;

    public ExpenseController(BalanceCalculationService service,
                             CurrentUserProvider currentUserProvider) {
        this.service = service;
        this.currentUserProvider = currentUserProvider;
    }

    /** Creates a shared expense for the authenticated creator. */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SharedExpenseResponse create(@Valid @RequestBody SharedExpenseRequest request) {
        UUID userId = currentUserProvider.requireCurrentUserId();
        return SharedExpenseResponse.from(service.createExpense(request, userId));
    }

    /** Returns net balances for the authenticated user. */
    @GetMapping("/balances")
    public Map<UUID, BigDecimal> balances() {
        UUID userId = currentUserProvider.requireCurrentUserId();
        return service.calculateNetBalances(userId, service.getExpensesForUser(userId));
    }
}