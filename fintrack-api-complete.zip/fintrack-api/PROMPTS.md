# PROMPTS.md — GitHub Copilot Prompt Chain

> Run these prompts in GitHub Copilot and capture the genuine screenshots requested by the assessment guide.

## Prompt 1 — Required Low-Effort Generation
**Mode:** Ask Mode  
**Technique:** Specificity (limited) / baseline generation

Exact required prompt:
> Generate a Transaction model and a Transaction service with create, get-by-user, and delete-all functions. Use a database.

Purpose: intentionally reproduce the unreviewed teammate output exactly as required by the assessment.

## Prompt 2 — Review
**Mode:** Ask Mode  
**Technique:** Role-based + constraint

> Act as a senior fintech security reviewer. Review `src/transactions/` for correctness, authorization, monetary precision, validation, persistence, error handling, architecture, and maintainability. Identify at least 8 concrete issues. Do not modify files. For each issue give location, severity, fintech impact, detection reasoning, and recommended fix.

## Prompt 3 — Contextual Architecture
**Mode:** Ask Mode  
**Technique:** Decomposition + specificity

> Using @workspace and #file:src/transactions, propose a production-ready layered design for the Transaction module using Java 21, Spring Boot, Spring Data JPA, validation, service-layer authorization, and BigDecimal for money. Separate controller, service, repository, entity and DTO responsibilities.

## Prompt 4 — Remediation
**Mode:** Agent Mode  
**Technique:** Constraint + decomposition

> Remediate the Transaction module according to `.github/copilot-instructions.md`. Create/update model, repository, service and controller. Use Spring Data JPA, BigDecimal, validation, specific exceptions, structured SLF4J logging, constructor injection, and service-layer authorization. Show changes for review and do not introduce raw SQL.

## Prompt 5 — Expense Design
**Mode:** Ask Mode  
**Technique:** Role-based + decomposition

> Act as a senior backend engineer. Design the FinTrack expense splitting feature. Cover equal/custom splits, exact custom-sum validation, at least two participants, duplicate participants, creator authorization, and net balances across multiple expenses. Provide pseudocode and edge cases before implementation.

## Prompt 6 — Feature Build
**Mode:** Agent Mode  
**Technique:** Specificity + constraint

> Implement the expense splitting design using the existing project conventions. Add SharedExpense model/DTOs, BalanceCalculationService and REST endpoints. Use BigDecimal for money, validate custom totals exactly, reject fewer than two participants, enforce authorization, and keep business logic in services.

## Prompt 7 — Tests
**Mode:** Edit Mode / /tests  
**Technique:** Decomposition + constraint

> Add JUnit 5 tests for the expense splitting service covering: equal split among 3, valid custom split, invalid custom total, multiple-expense net balance, one-participant edge case, and unauthorized access. Do not remove existing tests.

## Prompt 8 — Documentation
**Mode:** Ask/Edit  
**Technique:** Iterative refinement

> Review the generated implementation against `.github/copilot-instructions.md` and list any deviations. Then propose targeted corrections for validation, authorization, monetary precision, error handling, and documentation.

## Post-Generation Corrections

1. Replaced floating-point monetary types with `BigDecimal`.
2. Added exact custom-share total validation.
3. Added minimum-two-participant validation.
4. Added duplicate participant validation.
5. Added service-layer authorization.
6. Added specific unauthorized/validation exceptions.
7. Added constructor injection and repository abstraction.
8. Added structured logging without sensitive financial payloads.
9. Added tests for invalid and authorization scenarios.
10. Reviewed generated code manually because business invariants and fintech risk cannot be delegated entirely to Copilot.
