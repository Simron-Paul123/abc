# FinTrack API — Expense Splitting

## Technology Stack
- Java 21
- Spring Boot 3.x
- Spring Web
- Spring Data JPA
- Bean Validation
- H2 Database
- JUnit 5 / Mockito
- Maven

## Architecture
Controller → Service → Repository → Entity

The application separates HTTP concerns, business logic, persistence, and domain models. Monetary values use `BigDecimal`; user ownership is checked in the service layer.

## Features
- Transaction CRUD operations
- User-scoped transaction access
- Shared expense creation
- Equal and custom expense splits
- Net balance calculation
- Validation and authorization
- Automated unit tests

## Run
```bash
mvn spring-boot:run
```

## Test
```bash
mvn test
```
