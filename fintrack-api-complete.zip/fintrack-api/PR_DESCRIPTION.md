# Pull Request — FinTrack Expense Splitting

## Summary
This PR introduces a production-oriented Expense Splitting capability for the FinTrack API. The Transaction module was first reviewed and remediated to address monetary precision, validation, authorization, persistence and error-handling concerns. The new feature supports equal and custom expense splits and calculates net balances between users. Automated tests cover the required happy paths, edge cases and unauthorized access.

## AI Tool Disclosure
GitHub Copilot was used through Ask Mode, Edit Mode, Agent Mode, slash commands such as `/explain`, `/fix`, `/tests`, and `/doc`, contextual references such as `#file`/`@workspace`, and project-specific `copilot-instructions.md`.

I accepted Copilot output for routine scaffolding and boilerplate after review. I overrode generated code where it conflicted with financial precision, authorization, validation, architecture or business rules.

Estimated implementation split: approximately 60% AI-assisted/generated and 40% manually reviewed, corrected or written.

The custom instructions improved consistency by explicitly requiring Java 21, Spring Data JPA, layered architecture, BigDecimal, validation, authorization and testing standards.

## Testing
Six required test scenarios are included:
- Equal split among three participants
- Valid custom split
- Invalid custom total
- Multiple-expense net balance
- One-participant edge case
- Unauthorized creator/access scenario

Known gaps: the sample implementation uses a simple authenticated-user header as an assessment stand-in rather than a full OAuth/JWT identity provider. Integration tests against a real production database and concurrency tests would be appropriate before production deployment.

## Risks & Trade-offs
The assessment implementation uses an `X-User-Id` header to demonstrate authorization boundaries without introducing a full authentication subsystem. In production this must be replaced by a trusted authenticated principal supplied by the security framework. The trade-off keeps the assessment focused while making the authorization logic explicit.

## Self-Review Checklist
- [x] No hardcoded secrets or PII
- [x] Inputs validated
- [x] Specific exceptions used
- [x] Code follows copilot-instructions.md
- [x] Copilot suggestions reviewed
- [x] Happy paths and error scenarios tested
- [x] Monetary values use BigDecimal
- [x] Authorization checked in service logic
- [x] Business invariants reviewed manually

## Peer Review Simulation

### Comment 1 — BalanceCalculationService
**Change:** Reject duplicate participant IDs before calculating shares.  
**Why:** Duplicate users can distort the split and produce incorrect balances even when the numeric total appears valid.

### Comment 2 — TransactionController
**Change:** Replace the assessment-only `X-User-Id` identity mechanism with a trusted Spring Security authenticated principal before production.  
**Why:** Client-controlled identity headers are not sufficient authentication.

### Comment 3 — Custom split validation
**Change:** Add explicit scale/rounding policy and test boundary values such as 0.01 and totals that cannot divide evenly.  
**Why:** Financial calculations need deterministic rounding behavior; this is a domain-specific issue that generic AI generation may overlook.

## AI Blind Spot
The rounding and balance semantics are domain-specific and depend on how FinTrack defines ownership, settlement and cents. AI can produce mathematically plausible code without knowing the product's accounting policy. Human review is required to validate the financial invariant against the actual business meaning.
