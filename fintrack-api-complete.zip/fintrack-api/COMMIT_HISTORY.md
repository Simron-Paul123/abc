# Suggested Git Commit History

Use these commands in your own Git repository so the history is genuine:

1. `feat: establish FinTrack project standards`
   - Add Maven/Spring Boot setup and Copilot instructions.
2. `fix: remediate transaction module`
   - Add repository, validation, BigDecimal money handling, authorization and structured errors.
3. `feat: add expense splitting`
   - Add shared expense models, split validation and balance calculation.
4. `test: add expense splitting coverage`
   - Add six required unit tests.
5. `docs: add assessment and PR documentation`
   - Add README, review, prompts, PR, strategy and architecture documents.
