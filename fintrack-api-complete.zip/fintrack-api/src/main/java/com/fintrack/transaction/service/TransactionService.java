package com.fintrack.transaction.service;

import com.fintrack.transaction.model.Transaction;
import com.fintrack.transaction.model.TransactionRequest;
import com.fintrack.transaction.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class TransactionService {
    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);
    private final TransactionRepository repository;

    public TransactionService(TransactionRepository repository) {
        this.repository = repository;
    }

    /** Creates a transaction owned by the supplied user. */
    @Transactional
    public Transaction create(TransactionRequest request, UUID authenticatedUserId) {
        requireOwner(request.userId(), authenticatedUserId);
        Transaction transaction = new Transaction(
                authenticatedUserId, request.amount(), request.description());
        Transaction saved = repository.save(transaction);
        log.info("Transaction created for user {}", authenticatedUserId);
        return saved;
    }

    /** Returns only transactions owned by the authenticated user. */
    @Transactional(readOnly = true)
    public List<Transaction> getByUser(UUID requestedUserId, UUID authenticatedUserId) {
        requireOwner(requestedUserId, authenticatedUserId);
        return repository.findAllByUserId(authenticatedUserId);
    }

    /** Deletes all transactions belonging to the authenticated user. */
    @Transactional
    public long deleteAll(UUID requestedUserId, UUID authenticatedUserId) {
        requireOwner(requestedUserId, authenticatedUserId);
        long deleted = repository.deleteByUserId(authenticatedUserId);
        log.info("Deleted {} transactions for user {}", deleted, authenticatedUserId);
        return deleted;
    }

    private void requireOwner(UUID requestedUserId, UUID authenticatedUserId) {
        if (!authenticatedUserId.equals(requestedUserId)) {
            throw new UnauthorizedAccessException("User is not authorised for this resource");
        }
    }
}
