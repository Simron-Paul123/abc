package com.fintrack.transaction.model;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.UUID;

public record TransactionRequest(
        @NotNull UUID userId,
        @NotNull @Positive BigDecimal amount,
        @NotBlank @Size(max = 500) String description
) {}
