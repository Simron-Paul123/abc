package com.fintrack.transaction.controller;

import com.fintrack.transaction.model.Transaction;
import com.fintrack.transaction.model.TransactionRequest;
import com.fintrack.transaction.service.TransactionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
    private final TransactionService service;

    public TransactionController(TransactionService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Transaction create(@Valid @RequestBody TransactionRequest request,
                              @RequestHeader("X-User-Id") UUID authenticatedUserId) {
        return service.create(request, authenticatedUserId);
    }

    @GetMapping("/user/{userId}")
    public List<Transaction> getByUser(@PathVariable UUID userId,
                                       @RequestHeader("X-User-Id") UUID authenticatedUserId) {
        return service.getByUser(userId, authenticatedUserId);
    }

    @DeleteMapping("/user/{userId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAll(@PathVariable UUID userId,
                          @RequestHeader("X-User-Id") UUID authenticatedUserId) {
        service.deleteAll(userId, authenticatedUserId);
    }
}
