package com.fintrack.expense.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public record SharedExpenseRequest(
        @NotNull UUID creator,
        @NotBlank @Size(max = 500) String description,
        @NotNull @Positive BigDecimal totalAmount,
        @NotNull SplitType splitType,
        @NotEmpty List<@Valid ParticipantShare> participants
) {}
