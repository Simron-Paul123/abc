package com.fintrack.expense.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public record SharedExpense(
        UUID id,
        UUID creator,
        String description,
        BigDecimal totalAmount,
        SplitType splitType,
        List<ParticipantShare> participants,
        Instant createdAt
) {}
