package com.fintrack.expense.model;

import java.math.BigDecimal;
import java.util.UUID;

public record ParticipantShare(UUID userId, BigDecimal amount) {}
