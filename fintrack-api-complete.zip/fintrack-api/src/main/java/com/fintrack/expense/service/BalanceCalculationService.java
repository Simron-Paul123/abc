package com.fintrack.expense.service;

import com.fintrack.expense.model.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;

@Service
public class BalanceCalculationService {

    /** Creates a shared expense after validating participants and calculating shares. */
    public SharedExpense createExpense(SharedExpenseRequest request, UUID authenticatedUserId) {
        if (!authenticatedUserId.equals(request.creator())) {
            throw new ExpenseValidationException("Only the creator may create the expense");
        }
        if (request.participants().size() < 2) {
            throw new ExpenseValidationException("An expense requires at least two participants");
        }

        Set<UUID> uniqueUsers = new HashSet<>();
        for (ParticipantShare p : request.participants()) {
            if (p.userId() == null || !uniqueUsers.add(p.userId())) {
                throw new ExpenseValidationException("Participants must be unique and non-null");
            }
        }

        List<ParticipantShare> shares = request.splitType() == SplitType.EQUAL
                ? equalShares(request.totalAmount(), request.participants())
                : validateCustomShares(request.totalAmount(), request.participants());

        return new SharedExpense(
                UUID.randomUUID(),
                request.creator(),
                request.description(),
                request.totalAmount(),
                request.splitType(),
                shares,
                Instant.now());
    }

    private List<ParticipantShare> equalShares(BigDecimal total, List<ParticipantShare> participants) {
        int count = participants.size();
        BigDecimal[] result = total.divideAndRemainder(BigDecimal.valueOf(count));
        BigDecimal base = total.divide(BigDecimal.valueOf(count), 2, RoundingMode.DOWN);
        BigDecimal remainder = total.subtract(base.multiply(BigDecimal.valueOf(count)));

        List<ParticipantShare> shares = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            BigDecimal amount = base;
            if (i == count - 1) amount = amount.add(remainder);
            shares.add(new ParticipantShare(participants.get(i).userId(), amount));
        }
        return shares;
    }

    private List<ParticipantShare> validateCustomShares(
            BigDecimal total, List<ParticipantShare> participants) {
        BigDecimal sum = participants.stream()
                .map(ParticipantShare::amount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        if (sum.compareTo(total) != 0) {
            throw new ExpenseValidationException("Custom shares must equal the total amount");
        }
        if (participants.stream().anyMatch(p -> p.amount() == null || p.amount().signum() < 0)) {
            throw new ExpenseValidationException("Custom shares cannot be negative or null");
        }
        return List.copyOf(participants);
    }

    /**
     * Calculates net balances from directed debts.
     * Positive value means the key user is owed; negative means the key user owes.
     */
    public Map<UUID, BigDecimal> calculateNetBalances(
            UUID userId, List<SharedExpense> expenses) {
        Map<UUID, BigDecimal> balances = new HashMap<>();

        for (SharedExpense expense : expenses) {
            for (ParticipantShare share : expense.participants()) {
                if (share.userId().equals(expense.creator())) continue;

                if (share.userId().equals(userId)) {
                    balances.merge(expense.creator(), share.amount(), BigDecimal::add);
                } else if (expense.creator().equals(userId)) {
                    balances.merge(share.userId(), share.amount().negate(), BigDecimal::add);
                }
            }
        }
        return balances;
    }
}
