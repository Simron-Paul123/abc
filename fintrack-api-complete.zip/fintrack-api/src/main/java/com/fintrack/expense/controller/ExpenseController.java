package com.fintrack.expense.controller;

import com.fintrack.expense.model.*;
import com.fintrack.expense.service.BalanceCalculationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {
    private final BalanceCalculationService service;

    public ExpenseController(BalanceCalculationService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SharedExpense create(@Valid @RequestBody SharedExpenseRequest request,
                                @RequestHeader("X-User-Id") UUID authenticatedUserId) {
        return service.createExpense(request, authenticatedUserId);
    }

    @GetMapping("/balances/{userId}")
    public Map<UUID, BigDecimal> balances(
            @PathVariable UUID userId,
            @RequestHeader("X-User-Id") UUID authenticatedUserId,
            @RequestParam List<String> ignored) {
        if (!userId.equals(authenticatedUserId)) {
            throw new com.fintrack.transaction.service.UnauthorizedAccessException(
                    "User is not authorised for this resource");
        }
        return Map.of();
    }
}
