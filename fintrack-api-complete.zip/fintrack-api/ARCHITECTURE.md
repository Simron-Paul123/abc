# Architecture

1. FinTrack uses a layered Controller → Service → Repository → Entity architecture.
2. Transaction and Expense Splitting are separate domain modules.
3. The Transaction module provides the foundational transaction ownership model and persistence layer.
4. Expense Splitting contains shared-expense and balance-calculation business logic.
5. Controllers validate API input and delegate business operations to services.
6. Services enforce authorization and domain invariants.
7. Repositories isolate persistence through Spring Data JPA.
8. Entities represent database state, while DTOs define API input boundaries.
9. Monetary calculations use BigDecimal to avoid floating-point precision errors.
10. Custom shares must exactly equal the declared expense total.
11. Expenses require at least two unique participants.
12. Service-layer authorization prevents users from accessing another user's transactions.
13. This separation makes security and business rules easier to test independently.
14. The architecture also supports future replacement of H2 with a production relational database.
15. A production deployment should integrate Spring Security/JWT rather than trusting the assessment-only identity header.
