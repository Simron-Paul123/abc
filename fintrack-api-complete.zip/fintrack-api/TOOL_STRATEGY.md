# Tool Strategy & Reflection

## Feature Usage Log

| # | Case Study Area | Copilot Feature | Why this feature | What happened |
|---|---|---|---|---|
| 1 | Initial Transaction generation | Ask Mode | Required low-effort generation without changing files | Generated a quick baseline with issues requiring review. |
| 2 | Code review | Ask Mode + /explain | Best for understanding suspicious code before changing it | Helped identify structural and validation concerns. |
| 3 | Project context | @workspace / #file | Needed project-aware analysis rather than isolated snippets | Provided architectural context. |
| 4 | Transaction remediation | Agent Mode | Efficient for coordinated multi-file changes | Proposed model/repository/service/controller changes. |
| 5 | Targeted correction | Edit Mode | Useful when a specific generated function needed controlled changes | Produced reviewable diffs. |
| 6 | Tests | /tests | Focused generation of test cases | Generated a starting test suite which was manually reviewed. |
| 7 | Documentation | /doc | Efficient for public-method documentation | Produced JavaDoc candidates. |
| 8 | Final cleanup | /fix | Useful for targeted compile/style issues | Suggested fixes which were reviewed before acceptance. |

## Scenario Responses

### 1. Complex 500-line function
**Feature: Ask Mode + `/explain`.**  
I would use `/explain` on the function in context so Copilot can describe control flow and dependencies without immediately modifying the code. This is safer than Agent/Edit Mode when I am still learning the unfamiliar code.

### 2. Error handling across 8 routes
**Feature: Agent Mode with `@workspace`.**  
Agent Mode can coordinate changes across the related route handlers and shared exception-handling code. I would first establish the desired exception contract, then review the multi-file diff before accepting it.

### 3. International phone regex
**Feature: Ask Mode / Quick Chat.**  
Ask Mode is appropriate for quickly checking examples and edge cases without changing source files. I would also run concrete tests because regex reasoning alone is not sufficient verification.

### 4. Automated PR quality checks
**Feature: GitHub Actions / repository automation, supported by Copilot.**  
Copilot can generate the workflow configuration, but the actual enforcement should be implemented in CI rather than relying on Copilot at review time. This gives repeatable automated checks for every pull request.

### 5. AI-generated authentication review
**Feature: Ask Mode + `/explain` + `@workspace`.**  
I would ask Copilot to review authentication for common security vulnerabilities while providing workspace context. Human security review remains essential for trust boundaries, authorization semantics and threat-model decisions.

### 6. Consistent project conventions
**Feature: `.github/copilot-instructions.md`.**  
Custom instructions are specifically intended to communicate project-wide conventions to Copilot across sessions and developers. This is more appropriate than repeating architecture rules in every prompt.

## Limitations Encountered

| # | Prompted / Did | Copilot Output | Detection | Fix | Next time |
|---|---|---|---|---|---|
| 1 | Asked Copilot to create money-related fields | Suggested numeric representation that could be unsafe for currency | Manual fintech review | Replaced with BigDecimal and explicit precision | Put monetary constraints in instructions before generation. |
| 2 | Asked for user-scoped transaction operations | Generated logic that could trust a supplied user identifier | Security review | Added service-layer ownership checks | Include an explicit threat model in the prompt. |
| 3 | Asked for equal splitting | Produced straightforward division without fully defining remainder policy | Boundary testing/manual review | Added deterministic remainder handling | Specify rounding and settlement policy before generation. |
