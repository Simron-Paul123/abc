# FinTrack Copilot Instructions

## Technology
Use Java 21, Spring Boot, Spring Data JPA, Bean Validation, H2, JUnit 5 and Mockito.

## Architecture
Follow Controller → Service → Repository → Entity.
- Controllers handle HTTP mapping and request/response DTOs.
- Services contain business rules and authorization checks.
- Repositories contain persistence operations only.
- Entities represent persisted domain state.
- Prefer DTOs at API boundaries.

## Coding Standards
- Use clear Java naming conventions.
- Prefer immutable request/response DTOs where practical.
- Use `BigDecimal` for monetary amounts; never use `double` or `float` for money.
- Use `UUID` for externally exposed user/entity identifiers.
- Add JavaDoc to public service methods and public API-facing methods.
- Use constructor injection.
- Avoid raw SQL unless explicitly justified.
- Do not expose entity objects directly from public APIs when a DTO is appropriate.

## Validation
- Validate null, blank, negative and zero monetary values where applicable.
- Validate that custom expense shares exactly equal the expense total.
- An expense must contain at least two participants.
- Reject duplicate participant IDs.
- Return specific, meaningful errors.

## Security
- Never trust a user ID supplied by a client when the authenticated identity is available.
- Users may access only their own transactions and permitted balance information.
- Never log passwords, tokens, secrets or sensitive financial details.
- Apply authorization checks in the service layer.
- Do not hardcode credentials or secrets.

## Logging and Errors
- Use structured SLF4J logging.
- Log business events without sensitive financial payloads.
- Use specific exceptions rather than generic `Exception`.
- Return consistent API error responses.

## Testing
Tests must cover:
- Happy paths
- Validation failures
- Authorization failures
- Boundary cases
- Balance calculations
- Equal and custom splits
- Repository/service interactions where appropriate

Always review generated code before accepting it. Prefer correctness and security over generated-code convenience.
